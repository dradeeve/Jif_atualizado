<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "usuarios_cadastrados";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
C:\Users\Aluno\Downloads\JIF (2)\JIF (2)\conexao.php